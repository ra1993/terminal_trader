import hashlib
import requests


SALT = "random salt here".encode()

def hash_password(password):
    hashed_pw = hashlib.sha512(password.encode() + SALT).hexdigest()
    return hashed_pw

def get_price(ticker):
    #TODO: get price from IEX Cloud API
    response = requests.get('http://api.endpoint.here')
    data = response.json()
    return data["key here"]
